﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CodeChallenge.Models;
using Microsoft.Extensions.Logging;
using CodeChallenge.Repositories;

namespace CodeChallenge.Services
{
	public class CompensationService: ICompensationService
	{
		private readonly ICompensationRepository _compensationRepository;
		private readonly ILogger<CompensationService> _logger;

		public CompensationService(ILogger<CompensationService> logger, ICompensationRepository compensationRepository)
		{
			_compensationRepository = compensationRepository;
			_logger = logger;
		}

		public Compensation CreateCompensation(string id, double salary, DateTime effectiveDate)
		{
			if (id != null)
			{
				_compensationRepository.Add(id,salary,effectiveDate);
				_compensationRepository.SaveAsync().Wait();
			}

			Compensation compensation = new Compensation {Id = id, Salary = salary, EffectiveDate = effectiveDate };

			return compensation;
		}

		public Compensation GetCompensation(string id)
		{
			if (!String.IsNullOrEmpty(id))
			{
				return _compensationRepository.GetCompensation(id);
			}

			return null;
		}
	}
}
