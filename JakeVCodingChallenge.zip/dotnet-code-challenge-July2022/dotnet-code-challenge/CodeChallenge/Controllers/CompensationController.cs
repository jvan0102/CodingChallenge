﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CodeChallenge.Services;
using CodeChallenge.Models;

namespace CodeChallenge.Controllers
{
	[ApiController]
	[Route("api/compensation")]
	public class CompensationController: ControllerBase
	{
		private readonly ILogger _logger;
		private readonly ICompensationService _compensationService;

		public CompensationController(ILogger<CompensationController> logger, ICompensationService compensationService)
		{
			_logger = logger;
			_compensationService = compensationService;
		}

		[HttpPost]
		public IActionResult CreateCompensation([FromBody] Compensation compensation)
		{
			_logger.LogDebug($"Received employee create request for '{compensation.Id}'");

			_compensationService.CreateCompensation(compensation.Id, compensation.Salary, compensation.EffectiveDate);

			return CreatedAtRoute("getCompensation", new { id = compensation.Id }, compensation);
		}

		[HttpGet("{id}", Name = "getCompensation")]
		public IActionResult GetCompensation(String id)
		{
			_logger.LogDebug($"Received compensation get request for '{id}'");

			var compensation = _compensationService.GetCompensation(id);

			if (compensation == null)
				return NotFound();

			return Ok(compensation);
		}
	}
}
