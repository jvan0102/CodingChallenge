﻿using CodeChallenge.Models;
using System;
using System.Threading.Tasks;

namespace CodeChallenge.Repositories
{
	public interface ICompensationRepository
	{
		Compensation GetCompensation(string id);
		Compensation Add(string id, double salary, DateTime effectiveDate);
		Task SaveAsync();
	}
}
