﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CodeChallenge.Models;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using CodeChallenge.Data;

namespace CodeChallenge.Repositories
{
	public class CompensationRespository : ICompensationRepository
	{
		private readonly CompensationContext _compensationContext;
		private readonly ILogger<ICompensationRepository> _logger;

		public CompensationRespository(ILogger<ICompensationRepository> logger, CompensationContext compensationContext)
		{
			_compensationContext = compensationContext;
			_logger = logger;
		}

		public Compensation Add(string id, double salary, DateTime effectiveDate)
		{
			Compensation compensation = new Compensation { Id = id, Salary = salary, EffectiveDate = effectiveDate };

			_compensationContext.Compensations.Add(compensation);

			return compensation;
		}

		public Compensation GetCompensation(string id)
		{
			return _compensationContext.Compensations.SingleOrDefault(e => e.Id == id);
		}

		public Task SaveAsync()
		{
			return _compensationContext.SaveChangesAsync();
		}
	}
}
