﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CodeChallenge.Models;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using CodeChallenge.Data;
using System.Collections;
using System.Xml.Linq;

namespace CodeChallenge.Repositories
{
	public class ReportingStructureRespository : IReportingStructureRepository
	{
		private readonly EmployeeContext _reportingStructureContext;
		private readonly ILogger<IReportingStructureRepository> _logger;

		public ReportingStructureRespository(ILogger<IReportingStructureRepository> logger, EmployeeContext reportingStructureContext)
		{
			_reportingStructureContext = reportingStructureContext;
			_logger = logger;
		}

		public ReportingStructure GetReportingStructureByEmployeeId(string id)
		{
			List<int> reported = new List<int>();
			//I ended up trying to work with the below because this seemed to fix the direct reports seeder.
			//If I attempted to build off of the employee immedately, all direct reports returned as null.
			var reportingList = _reportingStructureContext.Employees.Select(v => v.DirectReports).ToList();
			foreach (var reporting in reportingList)
			{
				if(reporting.Count(e => e.EmployeeId == id) > 0)
					reported.Add(reportingList.IndexOf(reporting));
				//I retrieved a list of indexes because I cannot alter the list of lists while moving through its collection.
			}
			foreach (var reporting in reported)
			{
				reportingList.RemoveAt(reporting);
				//I pop off the list containing the employee id requested because we know this is a higher tier and can be removed.
				//This works in a two tier system, but in a multi-tier system, we would want something like depth first or better.
				//Ideally, I should be able to get reports of the employee requested and then move down the nodes until the bottom, counting.
				//I am hoping that this shows I understand the request and coding. I am not sure why the seeder wasn't populating reports.
			}

			ReportingStructure reports = new ReportingStructure
			{
				//Any lists that has multiple lists, should be counted. If there is anything left with no counts, that employee does not have reports.
				NumberOfReports = reportingList.SelectMany(x => x).Count(),
				Employee = _reportingStructureContext.Employees.SingleOrDefault(e => e.EmployeeId == id),
				//Once the seeder was fixed, this returned the structure we expected to see, which was a requirement.
				//If I attmpted anything else first, reports were null.
				//I am not sure if I have a setting fumbled or misunderstood what FixUpReferences should be doing.
			};			
			//Naming is the hardest part of software engineering
			return reports;
		}
	}
}
