﻿using System;
using System.Collections.Generic;

namespace CodeChallenge.Models
{
	public class ReportingStructure
	{
		public int NumberOfReports { get; set; }
		public Employee Employee { get; set; }
	}
}
